# CAMPOST Billing - Android App

Mobile billing management app for CAMPOST MANKON.

## 📱 Quick Install (APK)

If you just want to install the app on your phone:

1. Download the APK file from releases
2. Enable "Install from Unknown Sources" on your Android phone
3. Install the APK

## 🛠️ Build From Source

### Requirements
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- Android Studio (for building APK)
- OR Expo account (for cloud builds)

### Option 1: Expo Go (For Testing)

1. Install Expo Go app on your phone from Play Store
2. Run these commands:
```bash
cd campost-mobile
npm install
npx expo start
```
3. Scan the QR code with Expo Go app

### Option 2: Build APK (Expo Cloud)

1. Create free account at https://expo.dev
2. Install EAS CLI: `npm install -g eas-cli`
3. Login: `eas login`
4. Build:
```bash
cd campost-mobile
npm install
eas build -p android --profile preview
```
5. Download APK from Expo dashboard

### Option 3: Build APK Locally

1. Install Android Studio
2. Run:
```bash
npx expo prebuild
cd android
./gradlew assembleRelease
```
3. APK will be in `android/app/build/outputs/apk/release/`

## 📋 Features

- 📊 Dashboard with billing overview
- 📄 View all bills
- ➕ Create new bills (2026+)
- 💰 Record payments
- 📋 Statement of account
- 💾 Offline storage (data saved on phone)

## 👤 Client Info

- **Name:** GHOUENZEN Soulemanou
- **Address:** B.P 36 Mankon-Bamenda
- **Tel:** 675299868

## 💰 Pre-loaded Data

- 16 quarterly bills (Q1-2022 to Q4-2025)
- 510,000 XAF per quarter
- 3,500,000 XAF distributed as payments
- 4,660,000 XAF outstanding

---
CAMPOST Billing Mobile v1.0.0
