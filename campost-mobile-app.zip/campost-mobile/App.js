import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Alert, Modal, FlatList, SafeAreaView, StatusBar
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

// Colors
const COLORS = {
  primary: '#1a365d',
  primaryLight: '#2c5282',
  accent: '#d69e2e',
  success: '#38a169',
  danger: '#e53e3e',
  warning: '#ecc94b',
  background: '#f7fafc',
  white: '#ffffff',
  text: '#1a202c',
  textLight: '#718096',
  border: '#e2e8f0',
};

// Config
const CONFIG = {
  clientName: 'GHOUENZEN Soulemanou',
  clientAddress: 'B.P 36 Mankon-Bamenda',
  clientTel: '675299868',
  accountNo: '12003 14012 10868895015 89',
  tenantName: 'CAMPOST MANKON',
  rentPerMonth: 200000,
  taxRate: 0.15,
  quarterlyAmount: 510000,
};

// Generate default bills
const generateDefaultBills = () => {
  const bills = [];
  const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];
  const periods = ['January to March', 'April to June', 'July to September', 'October to December'];
  let remaining = 3500000;
  const amt = 510000;

  for (let year = 2022; year <= 2025; year++) {
    for (let q = 0; q < 4; q++) {
      let paid = 0;
      if (remaining >= amt) { paid = amt; remaining -= amt; }
      else if (remaining > 0) { paid = remaining; remaining = 0; }
      
      bills.push({
        billNumber: `${quarters[q]}-${year}-00${q + 1}`,
        quarter: quarters[q],
        year: year,
        period: periods[q],
        amountDue: amt,
        paidAmount: paid,
        outstanding: amt - paid,
        isNew: false,
      });
    }
  }
  return bills;
};

// Format number with commas
const formatNumber = (n) => n ? n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") : '0';

// Storage functions
const STORAGE_KEY = '@campost_bills';
const PAYMENTS_KEY = '@campost_payments';

const loadBills = async () => {
  try {
    const data = await AsyncStorage.getItem(STORAGE_KEY);
    if (data) return JSON.parse(data);
    const defaultBills = generateDefaultBills();
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(defaultBills));
    return defaultBills;
  } catch (e) {
    return generateDefaultBills();
  }
};

const saveBills = async (bills) => {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(bills));
  } catch (e) {}
};

const loadPayments = async () => {
  try {
    const data = await AsyncStorage.getItem(PAYMENTS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

const savePayments = async (payments) => {
  try {
    await AsyncStorage.setItem(PAYMENTS_KEY, JSON.stringify(payments));
  } catch (e) {}
};

// Dashboard Screen
function DashboardScreen() {
  const [bills, setBills] = useState([]);
  const [stats, setStats] = useState({ total: 0, due: 0, paid: 0, outstanding: 0 });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await loadBills();
    setBills(data);
    let due = 0, paid = 0, out = 0;
    data.forEach(b => { due += b.amountDue; paid += b.paidAmount; out += b.outstanding; });
    setStats({ total: data.length, due, paid, outstanding: out });
  };

  const outstandingBills = bills.filter(b => b.outstanding > 0).slice(-5).reverse();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>CAMPOST MANKON</Text>
          <Text style={styles.headerSubtitle}>Billing Management</Text>
        </View>

        <View style={styles.statsGrid}>
          <View style={[styles.statCard, { borderTopColor: COLORS.primaryLight }]}>
            <Text style={styles.statIcon}>📄</Text>
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>Total Bills</Text>
          </View>
          <View style={[styles.statCard, { borderTopColor: COLORS.accent }]}>
            <Text style={styles.statIcon}>💵</Text>
            <Text style={styles.statValue}>{formatNumber(stats.due)}</Text>
            <Text style={styles.statLabel}>Total Due</Text>
          </View>
          <View style={[styles.statCard, { borderTopColor: COLORS.success }]}>
            <Text style={styles.statIcon}>✅</Text>
            <Text style={styles.statValue}>{formatNumber(stats.paid)}</Text>
            <Text style={styles.statLabel}>Paid</Text>
          </View>
          <View style={[styles.statCard, { borderTopColor: COLORS.danger }]}>
            <Text style={styles.statIcon}>⚠️</Text>
            <Text style={styles.statValue}>{formatNumber(stats.outstanding)}</Text>
            <Text style={styles.statLabel}>Outstanding</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Outstanding Bills</Text>
          </View>
          {outstandingBills.map((bill, index) => (
            <View key={index} style={styles.billRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.billNumber}>{bill.billNumber}</Text>
                <Text style={styles.billPeriod}>{bill.period} {bill.year}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.amountNegative}>{formatNumber(bill.outstanding)} XAF</Text>
                <Text style={[styles.badge, bill.paidAmount > 0 ? styles.badgePartial : styles.badgeUnpaid]}>
                  {bill.paidAmount > 0 ? 'Partial' : 'Unpaid'}
                </Text>
              </View>
            </View>
          ))}
          {outstandingBills.length === 0 && (
            <Text style={styles.emptyText}>All bills paid! 🎉</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Bills Screen
function BillsScreen() {
  const [bills, setBills] = useState([]);
  const [selectedBill, setSelectedBill] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await loadBills();
    setBills(data);
  };

  const viewBill = (bill) => {
    setSelectedBill(bill);
    setModalVisible(true);
  };

  const renderBill = ({ item }) => (
    <TouchableOpacity style={styles.billRow} onPress={() => viewBill(item)}>
      <View style={{ flex: 1 }}>
        <Text style={styles.billNumber}>{item.billNumber}</Text>
        <Text style={styles.billPeriod}>{item.period} {item.year}</Text>
      </View>
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={item.outstanding > 0 ? styles.amountNegative : styles.amountPositive}>
          {formatNumber(item.outstanding)} XAF
        </Text>
        <Text style={[styles.badge, 
          item.outstanding === 0 ? styles.badgePaid : 
          item.paidAmount > 0 ? styles.badgePartial : styles.badgeUnpaid
        ]}>
          {item.outstanding === 0 ? 'Paid' : item.paidAmount > 0 ? 'Partial' : 'Unpaid'}
        </Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📄 All Bills</Text>
      </View>
      
      <FlatList
        data={bills}
        keyExtractor={(item) => item.billNumber}
        renderItem={renderBill}
        contentContainerStyle={{ padding: 16 }}
      />

      <Modal visible={modalVisible} animationType="slide" onRequestClose={() => setModalVisible(false)}>
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Bill Preview</Text>
            <TouchableOpacity onPress={() => setModalVisible(false)}>
              <Text style={styles.modalClose}>✕</Text>
            </TouchableOpacity>
          </View>
          {selectedBill && (
            <ScrollView style={styles.billPreview}>
              <Text style={styles.billPreviewTitle}>RENT BILL</Text>
              <Text style={styles.billPreviewText}>{CONFIG.clientName}</Text>
              <Text style={styles.billPreviewText}>{CONFIG.clientAddress}</Text>
              <Text style={styles.billPreviewText}>Tel: {CONFIG.clientTel}</Text>
              
              <View style={styles.divider} />
              
              <View style={styles.billDetail}>
                <Text style={styles.billDetailLabel}>Bill Number:</Text>
                <Text style={styles.billDetailValue}>{selectedBill.billNumber}</Text>
              </View>
              <View style={styles.billDetail}>
                <Text style={styles.billDetailLabel}>Period:</Text>
                <Text style={styles.billDetailValue}>{selectedBill.period} {selectedBill.year}</Text>
              </View>
              <View style={styles.billDetail}>
                <Text style={styles.billDetailLabel}>Tenant:</Text>
                <Text style={styles.billDetailValue}>{CONFIG.tenantName}</Text>
              </View>
              
              <View style={styles.divider} />
              
              <View style={styles.billDetail}>
                <Text style={styles.billDetailLabel}>Quarterly Rent:</Text>
                <Text style={styles.billDetailValue}>{formatNumber(600000)} XAF</Text>
              </View>
              <View style={styles.billDetail}>
                <Text style={styles.billDetailLabel}>Less 15% Tax:</Text>
                <Text style={styles.billDetailValue}>({formatNumber(90000)}) XAF</Text>
              </View>
              {selectedBill.paidAmount > 0 && selectedBill.outstanding > 0 && (
                <View style={styles.billDetail}>
                  <Text style={styles.billDetailLabel}>Less Advance:</Text>
                  <Text style={styles.billDetailValue}>({formatNumber(selectedBill.paidAmount)}) XAF</Text>
                </View>
              )}
              
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>TOTAL DUE:</Text>
                <Text style={styles.totalValue}>{formatNumber(selectedBill.outstanding)} XAF</Text>
              </View>
            </ScrollView>
          )}
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

// New Bill Screen
function NewBillScreen() {
  const [quarter, setQuarter] = useState('Q1');
  const [year, setYear] = useState('2026');
  const [amount, setAmount] = useState('510000');

  const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];
  const years = ['2026', '2027', '2028', '2029', '2030'];
  const periods = {
    'Q1': 'January to March',
    'Q2': 'April to June', 
    'Q3': 'July to September',
    'Q4': 'October to December'
  };

  const createBill = async () => {
    const billNumber = `${quarter}-${year}-00${quarters.indexOf(quarter) + 1}`;
    const bills = await loadBills();
    
    if (bills.find(b => b.billNumber === billNumber)) {
      Alert.alert('Error', 'Bill already exists!');
      return;
    }

    const newBill = {
      billNumber,
      quarter,
      year: parseInt(year),
      period: periods[quarter],
      amountDue: parseInt(amount),
      paidAmount: 0,
      outstanding: parseInt(amount),
      isNew: true,
    };

    bills.push(newBill);
    await saveBills(bills);
    Alert.alert('Success', `Bill ${billNumber} created!`);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>➕ Create New Bill</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.inputLabel}>Quarter</Text>
          <View style={styles.pickerRow}>
            {quarters.map(q => (
              <TouchableOpacity 
                key={q} 
                style={[styles.pickerButton, quarter === q && styles.pickerButtonActive]}
                onPress={() => setQuarter(q)}
              >
                <Text style={[styles.pickerButtonText, quarter === q && styles.pickerButtonTextActive]}>{q}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.inputLabel}>Year</Text>
          <View style={styles.pickerRow}>
            {years.map(y => (
              <TouchableOpacity 
                key={y} 
                style={[styles.pickerButton, year === y && styles.pickerButtonActive]}
                onPress={() => setYear(y)}
              >
                <Text style={[styles.pickerButtonText, year === y && styles.pickerButtonTextActive]}>{y}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.inputLabel}>Amount (XAF)</Text>
          <TextInput
            style={styles.input}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
          />

          <Text style={styles.inputLabel}>Bill Number (Auto)</Text>
          <TextInput
            style={[styles.input, styles.inputReadonly]}
            value={`${quarter}-${year}-00${quarters.indexOf(quarter) + 1}`}
            editable={false}
          />

          <TouchableOpacity style={styles.primaryButton} onPress={createBill}>
            <Text style={styles.primaryButtonText}>✅ Create Bill</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Payments Screen
function PaymentsScreen() {
  const [bills, setBills] = useState([]);
  const [payments, setPayments] = useState([]);
  const [selectedBill, setSelectedBill] = useState('');
  const [amount, setAmount] = useState('');
  const [reference, setReference] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const billsData = await loadBills();
    const paymentsData = await loadPayments();
    setBills(billsData.filter(b => b.outstanding > 0));
    setPayments(paymentsData);
  };

  const recordPayment = async () => {
    if (!selectedBill) {
      Alert.alert('Error', 'Select a bill!');
      return;
    }
    if (!amount || parseInt(amount) <= 0) {
      Alert.alert('Error', 'Enter valid amount!');
      return;
    }

    const allBills = await loadBills();
    const bill = allBills.find(b => b.billNumber === selectedBill);
    
    if (parseInt(amount) > bill.outstanding) {
      Alert.alert('Error', 'Amount exceeds outstanding!');
      return;
    }

    // Update bill
    bill.paidAmount += parseInt(amount);
    bill.outstanding -= parseInt(amount);
    await saveBills(allBills);

    // Save payment
    const allPayments = await loadPayments();
    allPayments.unshift({
      billNumber: selectedBill,
      amount: parseInt(amount),
      date: new Date().toISOString(),
      reference: reference || '-'
    });
    await savePayments(allPayments);

    Alert.alert('Success', `${formatNumber(amount)} XAF recorded!`);
    setAmount('');
    setReference('');
    setSelectedBill('');
    loadData();
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>💰 Record Payment</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.inputLabel}>Select Bill</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.pickerRow}>
              {bills.map(b => (
                <TouchableOpacity 
                  key={b.billNumber} 
                  style={[styles.billPickerButton, selectedBill === b.billNumber && styles.pickerButtonActive]}
                  onPress={() => setSelectedBill(b.billNumber)}
                >
                  <Text style={[styles.pickerButtonText, selectedBill === b.billNumber && styles.pickerButtonTextActive]}>
                    {b.billNumber}
                  </Text>
                  <Text style={[styles.pickerButtonSubtext, selectedBill === b.billNumber && styles.pickerButtonTextActive]}>
                    {formatNumber(b.outstanding)} XAF
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>

          <Text style={styles.inputLabel}>Amount (XAF)</Text>
          <TextInput
            style={styles.input}
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            placeholder="Enter amount"
          />

          <Text style={styles.inputLabel}>Reference (Optional)</Text>
          <TextInput
            style={styles.input}
            value={reference}
            onChangeText={setReference}
            placeholder="Receipt #, Bank Ref..."
          />

          <TouchableOpacity style={styles.successButton} onPress={recordPayment}>
            <Text style={styles.primaryButtonText}>💾 Save Payment</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>Payment History</Text>
          </View>
          {payments.slice(0, 10).map((p, i) => (
            <View key={i} style={styles.billRow}>
              <View>
                <Text style={styles.billNumber}>{p.billNumber}</Text>
                <Text style={styles.billPeriod}>{new Date(p.date).toLocaleDateString()}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.amountPositive}>{formatNumber(p.amount)} XAF</Text>
                <Text style={styles.billPeriod}>{p.reference}</Text>
              </View>
            </View>
          ))}
          {payments.length === 0 && (
            <Text style={styles.emptyText}>No payments recorded</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Statement Screen
function StatementScreen() {
  const [bills, setBills] = useState([]);
  const [stats, setStats] = useState({ due: 0, paid: 0, outstanding: 0 });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await loadBills();
    setBills(data);
    let due = 0, paid = 0, out = 0;
    data.forEach(b => { due += b.amountDue; paid += b.paidAmount; out += b.outstanding; });
    setStats({ due, paid, outstanding: out });
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>📋 Statement of Account</Text>
        </View>

        <View style={styles.clientCard}>
          <Text style={styles.clientName}>{CONFIG.clientName}</Text>
          <Text style={styles.clientInfo}>{CONFIG.clientAddress}</Text>
          <Text style={styles.clientInfo}>Tel: {CONFIG.clientTel}</Text>
          <Text style={styles.clientInfo}>Account: {CONFIG.accountNo}</Text>
        </View>

        <View style={styles.summaryRow}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Total Due</Text>
            <Text style={styles.summaryValue}>{formatNumber(stats.due)}</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Paid</Text>
            <Text style={[styles.summaryValue, { color: COLORS.success }]}>{formatNumber(stats.paid)}</Text>
          </View>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryLabel}>Outstanding</Text>
            <Text style={[styles.summaryValue, { color: COLORS.danger }]}>{formatNumber(stats.outstanding)}</Text>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>All Bills</Text>
          </View>
          {bills.map((bill, index) => (
            <View key={index} style={[styles.billRow, bill.isNew && styles.newBillRow]}>
              <View style={{ flex: 1 }}>
                <Text style={styles.billNumber}>
                  {bill.billNumber} {bill.isNew && <Text style={styles.newBadge}>NEW</Text>}
                </Text>
                <Text style={styles.billPeriod}>{bill.period} {bill.year}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={styles.billAmount}>{formatNumber(bill.amountDue)}</Text>
                <Text style={bill.outstanding > 0 ? styles.amountNegative : styles.amountPositive}>
                  {formatNumber(bill.outstanding)} due
                </Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Main App
export default function App() {
  return (
    <NavigationContainer>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.primary} />
      <Tab.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.textLight,
          tabBarStyle: { height: 60, paddingBottom: 8, paddingTop: 8 },
          tabBarLabelStyle: { fontSize: 11 },
        }}
      >
        <Tab.Screen 
          name="Dashboard" 
          component={DashboardScreen} 
          options={{ tabBarIcon: () => <Text style={{ fontSize: 20 }}>📊</Text> }}
        />
        <Tab.Screen 
          name="Bills" 
          component={BillsScreen}
          options={{ tabBarIcon: () => <Text style={{ fontSize: 20 }}>📄</Text> }}
        />
        <Tab.Screen 
          name="New" 
          component={NewBillScreen}
          options={{ tabBarIcon: () => <Text style={{ fontSize: 20 }}>➕</Text> }}
        />
        <Tab.Screen 
          name="Pay" 
          component={PaymentsScreen}
          options={{ tabBarIcon: () => <Text style={{ fontSize: 20 }}>💰</Text> }}
        />
        <Tab.Screen 
          name="Statement" 
          component={StatementScreen}
          options={{ tabBarIcon: () => <Text style={{ fontSize: 20 }}>📋</Text> }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    backgroundColor: COLORS.primary,
    padding: 20,
    paddingTop: 10,
  },
  headerTitle: {
    color: COLORS.white,
    fontSize: 22,
    fontWeight: 'bold',
  },
  headerSubtitle: {
    color: COLORS.white,
    opacity: 0.8,
    fontSize: 14,
    marginTop: 4,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: 12,
    justifyContent: 'space-between',
  },
  statCard: {
    width: '48%',
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderTopWidth: 4,
    elevation: 2,
  },
  statIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  statLabel: {
    fontSize: 12,
    color: COLORS.textLight,
    marginTop: 4,
  },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    margin: 16,
    marginTop: 0,
    padding: 16,
    elevation: 2,
  },
  cardHeader: {
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    paddingBottom: 12,
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
  },
  billRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  billNumber: {
    fontWeight: 'bold',
    color: COLORS.text,
    fontSize: 14,
  },
  billPeriod: {
    color: COLORS.textLight,
    fontSize: 12,
    marginTop: 2,
  },
  billAmount: {
    fontSize: 14,
    color: COLORS.text,
  },
  amountPositive: {
    color: COLORS.success,
    fontWeight: '600',
    fontSize: 14,
  },
  amountNegative: {
    color: COLORS.danger,
    fontWeight: '600',
    fontSize: 14,
  },
  badge: {
    fontSize: 10,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    overflow: 'hidden',
    marginTop: 4,
  },
  badgePaid: {
    backgroundColor: '#c6f6d5',
    color: COLORS.success,
  },
  badgePartial: {
    backgroundColor: '#fefcbf',
    color: '#b7791f',
  },
  badgeUnpaid: {
    backgroundColor: '#fed7d7',
    color: COLORS.danger,
  },
  emptyText: {
    textAlign: 'center',
    color: COLORS.textLight,
    padding: 20,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 8,
    marginTop: 12,
  },
  input: {
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    backgroundColor: COLORS.white,
  },
  inputReadonly: {
    backgroundColor: COLORS.background,
    color: COLORS.textLight,
  },
  pickerRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  pickerButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
  },
  pickerButtonActive: {
    borderColor: COLORS.primary,
    backgroundColor: COLORS.primary,
  },
  pickerButtonText: {
    color: COLORS.text,
    fontWeight: '600',
  },
  pickerButtonTextActive: {
    color: COLORS.white,
  },
  pickerButtonSubtext: {
    fontSize: 10,
    color: COLORS.textLight,
    marginTop: 2,
  },
  billPickerButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: COLORS.border,
    backgroundColor: COLORS.white,
    marginRight: 8,
    minWidth: 100,
  },
  primaryButton: {
    backgroundColor: COLORS.primary,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  successButton: {
    backgroundColor: COLORS.success,
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 20,
  },
  primaryButtonText: {
    color: COLORS.white,
    fontSize: 16,
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: COLORS.primary,
    padding: 16,
  },
  modalTitle: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  modalClose: {
    color: COLORS.white,
    fontSize: 24,
  },
  billPreview: {
    padding: 20,
  },
  billPreviewTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    color: COLORS.primary,
    marginBottom: 16,
  },
  billPreviewText: {
    textAlign: 'center',
    color: COLORS.text,
    marginBottom: 4,
  },
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginVertical: 16,
  },
  billDetail: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  billDetailLabel: {
    color: COLORS.textLight,
  },
  billDetailValue: {
    fontWeight: '600',
    color: COLORS.text,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: COLORS.accent,
    padding: 16,
    borderRadius: 8,
    marginTop: 16,
  },
  totalLabel: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 16,
  },
  totalValue: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 18,
  },
  clientCard: {
    backgroundColor: COLORS.primary,
    margin: 16,
    padding: 16,
    borderRadius: 12,
  },
  clientName: {
    color: COLORS.white,
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  clientInfo: {
    color: COLORS.white,
    opacity: 0.9,
    fontSize: 13,
    marginBottom: 2,
  },
  summaryRow: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  summaryItem: {
    flex: 1,
    backgroundColor: COLORS.white,
    padding: 12,
    borderRadius: 8,
    marginHorizontal: 4,
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 11,
    color: COLORS.textLight,
  },
  summaryValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: COLORS.text,
    marginTop: 4,
  },
  newBillRow: {
    backgroundColor: 'rgba(66, 153, 225, 0.1)',
    marginHorizontal: -16,
    paddingHorizontal: 16,
    borderLeftWidth: 3,
    borderLeftColor: COLORS.primaryLight,
  },
  newBadge: {
    fontSize: 10,
    color: COLORS.primaryLight,
    fontWeight: 'bold',
  },
});
