# 📱 Install CAMPOST Billing on Android

## Option 1: Install as Web App (Easiest - No Build Required!)

This is the **easiest way** - just open in Chrome and install!

### Steps:
1. Copy the `campost-mobile` folder to your computer
2. Open the folder and double-click `index.html` 
   OR host it on a local server
3. On your Android phone, open Chrome
4. Go to the URL where the app is hosted
5. Tap the **⋮** menu (three dots)
6. Select **"Add to Home screen"** or **"Install app"**
7. The app icon will appear on your home screen!

### Quick Local Server:
If you have Node.js installed:
```bash
cd campost-mobile
npx serve .
```
Then open `http://your-ip:3000` on your phone

### Using Python:
```bash
cd campost-mobile
python -m http.server 8000
```
Then open `http://your-ip:8000` on your phone

---

## Option 2: Build Native APK with Expo

### Requirements:
- Node.js 18+
- Expo account (free at expo.dev)

### Steps:
```bash
# Install dependencies
cd campost-mobile
npm install

# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Build APK (cloud build - free)
eas build -p android --profile preview

# Download APK from expo.dev dashboard
```

---

## Option 3: Use Online APK Builder

### Using PWA Builder:
1. Host your app online (GitHub Pages, Netlify, etc.)
2. Go to https://www.pwabuilder.com
3. Enter your app URL
4. Click "Build My PWA"
5. Download Android APK

### Using Capacitor:
1. Install Capacitor: `npm install @capacitor/core @capacitor/android`
2. Initialize: `npx cap init`
3. Add Android: `npx cap add android`
4. Build: `npx cap open android` (requires Android Studio)

---

## 📋 App Features

- 📊 Dashboard with billing overview
- 📄 View all bills (2022-2025 pre-loaded)
- ➕ Create new bills (2026+)
- 💰 Record payments
- 📋 Statement of account
- 💾 Offline storage - data saved on phone!

## 👤 Client Info

- **Name:** GHOUENZEN Soulemanou
- **Address:** B.P 36 Mankon-Bamenda
- **Tel:** 675299868
